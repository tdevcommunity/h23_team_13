<p> 
    code de confirmation <br>
    ------------------------- <br>
    &nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;
    <?php echo e($data['code']); ?>  <br>
    -------------------------  <br>
</p><?php /**PATH D:\TERANET\ticket_backend\resources\views/email/otp.blade.php ENDPATH**/ ?>