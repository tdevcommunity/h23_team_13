<p> 
    code de confirmation <br>
    ------------------------- <br>
    &nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;
    {{ $data['code'] }}  <br>
    -------------------------  <br>
</p>